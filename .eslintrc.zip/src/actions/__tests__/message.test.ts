/*
import { inputSchema } from "@/validators/schemas";
import { CreateReturn } from "./message.types";
import { encrypt, decrypt } from "@/lib/cypher";
import prisma from "@/lib/db";
*/

import prisma from "@/lib/db";
import { PrismaClient } from "@prisma/client";

jest.mock("@/lib/cypher", () => ({
  encrypt: jest.fn((text) => `encripted.${test}`),
  decrypt: jest.fn((text) => `decripted.${test}`),
}));

import {
  createMessage,
  /*getMessage,
    deleteMessage,
    deleteOlderMessages,*/
} from "../message";

describe("Message Actions", () => {
  //let prisma: typeof PrismaClient;

  await setup({
    server: true,
  });

  beforeEach(() => {
    //prisma = new PrismaClient();
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it.only("should create a message", async () => {
    const messageData = new FormData();
    messageData.append("message", "Test message");
    messageData.append("minutes", "10");
    messageData.append("deleteNext", "on");

    const createdMessage = {
      body: "",
      minutesToExpire: 10,
      nextVisit: true,
    };

    const result = await createMessage(undefined, messageData);

    expect(prisma.message.create).toHaveBeenCalledWith({ data: messageData });
    expect(result).toEqual(createdMessage);
  });
});

/*

import { PrismaClient } from "@prisma/client";
import { mockDeep, mockReset, DeepMockProxy } from "jest-mock-extended";

import prisma from "./src/lib/db";

jest.mock("./src/lib/db", () => ({
  __esModule: true,
  default: mockDeep<PrismaClient>(),
}));

beforeEach(() => {
  mockReset(prismaMock);
});

export const prismaMock = prisma as unknown as DeepMockProxy<PrismaClient>;

*/
