import prisma from "@/lib/db";
import { PrismaClient } from "@prisma/client";
import { mockDeep } from "jest-mock-extended";

import {
  createMessage,
  /*getMessage,
  deleteMessage,
  deleteOlderMessages,*/
} from "../message";

const client = new PrismaClient();

/*
jest.mock("@/lib/db", () => ({
  prisma: {
    message: {
      create: jest.fn(),
    },
  },
}));
*/

jest.mock("@/lib/db", () => ({
  __esModule: true,
  prisma: mockDeep<typeof PrismaClient>(),
}));

describe("Message Actions", () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it.only("should create a message", async () => {
    const messageData = new FormData();
    messageData.append("message", "Test message");
    messageData.append("minutes", "10");
    messageData.append("deleteNext", "on");

    const createdMessage = {
      body: "",
      minutesToExpire: 10,
      nextVisit: true,
    };

    /*
    prisma.message
      .create.mockImplementation((args) => ({
      ...args.data,
      id: "1",
      createdAt: new Date(),
      then: jest.fn(),
      catch: jest.fn(),
      finally: jest.fn(),
    }));
    */

    /*
    prisma.message.create.mockResolvedValue({
      data: createMessage,
    });
    */

    const result = await createMessage(undefined, messageData);

    expect(prisma.message.create).toHaveBeenCalledWith({ data: messageData });
    expect(result).toEqual(createdMessage);
  });

  /*
  it("should get a message by id", async () => {
    const messageId = "1";
    const message = { id: messageId, body: "Test message" };
    prisma.message.findUnique.mockResolvedValue(message);

    const result = await getMessage(messageId);

    expect(prisma.message.findUnique).toHaveBeenCalledWith({
      where: { id: messageId },
    });
    expect(result).toEqual(message);
  });

  it("should delete a message by id", async () => {
    const messageId = "1";
    const deletedMessage = { id: messageId, body: "Test message" };
    prisma.message.delete.mockResolvedValue(deletedMessage);

    const result = await deleteMessage(messageId);

    expect(prisma.message.delete).toHaveBeenCalledWith({
      where: { id: messageId },
    });
    expect(result).toEqual(deletedMessage);
  });

  it("should delete older messages", async () => {
    const reference = new Date();
    const messages = [
      {
        id: "1",
        createdAt: new Date(reference.getTime() - 1000),
        body: "Old message",
      },
    ];
    prisma.message.findMany.mockResolvedValue(messages);
    prisma.message.deleteMany.mockResolvedValue({ count: messages.length });

    const result = await deleteOlderMessages(reference);

    expect(prisma.message.findMany).toHaveBeenCalledWith({
      where: { createdAt: { lt: reference } },
    });
    expect(prisma.message.deleteMany).toHaveBeenCalledWith({
      where: { id: { in: messages.map((m) => m.id) } },
    });
    expect(result).toEqual({ count: messages.length });
  });
  */
});
