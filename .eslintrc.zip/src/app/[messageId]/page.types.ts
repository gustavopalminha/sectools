export type PageProps = { params: Promise<{ messageId: string }> };
