export type LinkViewerProps = {
  params: {
    messageId: string;
  };
};
