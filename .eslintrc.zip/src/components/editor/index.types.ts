export type EditorProps = {
  params: {
    readOnly: boolean;
    text?: string;
  };
};
