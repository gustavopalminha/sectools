import "@testing-library/jest-dom";

module.exports = {
  setupFilesAfterEnv: ["<rootDir>/setupTests.ts"],
};
